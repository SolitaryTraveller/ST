import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { DataServiceService } from '../data-service.service';
import { DB } from '../model/db';

@Component({
  selector: 'app-add-data',
  templateUrl: './add-data.component.html',
  styleUrls: ['./add-data.component.css']
})
export class AddDataComponent implements OnInit {

  addForm:FormGroup
  service:DataServiceService
  emp:DB
  constructor(  service:DataServiceService ) {
    this.service = service
   }

  ngOnInit() {
    this.addForm = new FormGroup({
      id: new FormControl(),
      name: new FormControl(),
      price : new FormControl(),
      department : new FormControl()
    })
  }

  onSubmit(){
    console.log("on submit called")
    let id = this.addForm.get("id").value
    let name = this.addForm.get("name").value
    let price = this.addForm.get("price").value
    let department = this.addForm.get("department").value
    this.emp = new DB(id,name,price,department)
    this.service.addData(this.emp)
  }

}
