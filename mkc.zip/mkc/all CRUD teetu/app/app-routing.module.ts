import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchListComponent } from './search-list/search-list.component';
import { FetchDataComponent } from './fetch-data/fetch-data.component';
import { AddDataComponent } from './add-data/add-data.component';
import { UpdateComponent } from './update/update.component';


const routes: Routes = [
  {
    path:"searchLink",
    component:SearchListComponent
  },
  {
    path:"productLink",
    component:FetchDataComponent
  },
  {
    path:"addLink",
    component:AddDataComponent
  },
  {
    path:"updateLink",
    component:UpdateComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
