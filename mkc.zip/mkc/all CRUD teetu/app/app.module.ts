import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FetchDataComponent } from './fetch-data/fetch-data.component';
import { DataServiceService } from './data-service.service'
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { SearchListComponent } from './search-list/search-list.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SortDataPipe } from './sort-data.pipe';
import { AddDataComponent } from './add-data/add-data.component';
import { UpdateComponent } from './update/update.component'

@NgModule({
  declarations: [
    AppComponent,
    FetchDataComponent,
    SearchListComponent,
    SortDataPipe,
    AddDataComponent,
    UpdateComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  providers: [ 
    DataServiceService,
     HttpClient
   ],
  bootstrap: [AppComponent]
})
export class AppModule { }
