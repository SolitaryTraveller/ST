import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { DB } from './model/db';
@Injectable({
  providedIn: 'root'
})
export class DataServiceService {

  http:HttpClient
  arrDB:DB[] = [];
  constructor(http:HttpClient) {
    this.http = http;
    console.log(this.arrDB)
    this.fetchingData()
   }

   isFetched:boolean = false;
   fetchingData(){
     this.http.get('../assets/db.json')
              .subscribe((data) =>{
                if(!this.isFetched){
                  this.isFetched = true;
                  this.convert(data);
                }
     })
    }

    convert(data:any){
      for(let e of data["Products"]){
        
        let d = new DB(e.id,e.name,e.price,e.category);
        this.arrDB.push(d);
      }
    }

    fetchAllData():DB[]{
      return this.arrDB;
    }

    addData(data:any){
      this.arrDB.push(data);
      console.log(this.arrDB)
    }

    searchByCategory(category:string):DB[]{
      let seachArr:DB[] = []
      for(let i = 0;i < this.arrDB.length ; i++){
        if(category == this.arrDB[i].category || category == this.arrDB[i].id.toString()){
          seachArr.push(this.arrDB[i])
        }
      }
      return seachArr;
    }


    onDelete(id:number){
      let index:number = -1
      for(let i = 0; i < this.arrDB.length ; i++){
        if(id == this.arrDB[i].id){
          index = i
          break;
        }
      }
      this.arrDB.splice(index,1)
    }

    onUpdate(id:number,price:number){
      for(let i = 0; i < this.arrDB.length ; i++){
        if(id == this.arrDB[i].id){
          this.arrDB[i].price = price;
        }
      }
    }
}
