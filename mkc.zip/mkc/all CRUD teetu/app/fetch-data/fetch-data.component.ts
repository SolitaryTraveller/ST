import { Component, OnInit } from '@angular/core';
import { DataServiceService } from '../data-service.service';
import { DB } from '../model/db';

@Component({
  selector: 'app-fetch-data',
  templateUrl: './fetch-data.component.html',
  styleUrls: ['./fetch-data.component.css']
})
export class FetchDataComponent implements OnInit {

  service:DataServiceService
  arrDB:DB[] = []
  constructor( service:DataServiceService ) {
    this.service = service;
   }

  ngOnInit() {
    this.service.fetchingData();
    this.arrDB = this.service.fetchAllData()
    console.log(this.arrDB)
  }
  onDelete(id:number){
    this.service.onDelete(id);
    this.arrDB = this.service.fetchAllData()
  }
  type:string;
  column:boolean = true
  sort(type:string){
    if(this.column){
      this.type = type;
      this.column = !this.column
    }
    else{
      this.type = type; //this imp
      this.column = !this.column //this imp
    }
  }

}
