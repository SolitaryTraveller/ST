import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl } from '@angular/forms';
import { DB } from '../model/db';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-search-list',
  templateUrl: './search-list.component.html',
  styleUrls: ['./search-list.component.css']
})
export class SearchListComponent implements OnInit {

  searchForm:FormGroup
  service:DataServiceService
  constructor(service:DataServiceService) {
    this.service = service
   }

  ngOnInit() {
    this.searchForm = new FormGroup({
      category: new FormControl()
    })
  }
  searchArr:DB[] = []
  onSubmit(){
    console.log("i call this")
    let cat = this.searchForm.get("category").value;
    console.log(cat)
    this.searchArr = this.service.searchByCategory(cat);
    if(this.searchArr.length <= 0){
      alert("no data found")
    }
    console.log(this.searchArr)
  }

}
