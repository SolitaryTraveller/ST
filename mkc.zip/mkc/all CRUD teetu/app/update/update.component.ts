import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { DataServiceService } from '../data-service.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  updateForm:FormGroup
  service:DataServiceService
  constructor( service:DataServiceService ) {
    this.service = service
   }

  ngOnInit() {
    this.updateForm = new FormGroup({
      id: new FormControl(),
      price: new FormControl()

    })
  }

  onSubmit(){
    let id = this.updateForm.get("id").value
    let price = this.updateForm.get("price").value
    this.service.onUpdate(id,price)
    

  }

}
