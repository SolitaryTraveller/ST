import { Component, OnInit } from '@angular/core';
import { Employee, MyserviceService } from '../myservice.service';

@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent implements OnInit {

  createdEmployee:Employee;
  createdFlag:boolean=false;
  service:MyserviceService;
  
  constructor(service:MyserviceService) { 
  this.service=service;}


  ngOnInit() {
  }

  add(data:any){
    this.createdEmployee=new Employee(data.ecode,data.ename,data.edesignation,data.eaddress,data.edob,data.egender,data.esal);
    this.service.add(this.createdEmployee);
    this.createdFlag=true;
  }
}
