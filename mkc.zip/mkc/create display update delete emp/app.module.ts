import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { DisplayemployeeComponent } from './displayemployee/displayemployee.component';
//import { HttpClient } from 'selenium-webdriver/http';
import { HttpClient,HttpClientModule} from '@angular/common/http';
import { MyserviceService } from './myservice.service';
import { OrderbyPipe } from './orderby.pipe';
import { UpdateComponent } from './update/update.component';
//import { OnlinelinkComponent } from './onlinelink/onlinelink.component';
//import { OnserviceComponent } from './onservice/onservice.component';

@NgModule({
  declarations: [
    AppComponent,
    AddemployeeComponent,
    DisplayemployeeComponent,
    OrderbyPipe,
    UpdateComponent,
   // OnlinelinkComponent,
   // OnserviceComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  
  ],
  providers: [HttpClient,MyserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
