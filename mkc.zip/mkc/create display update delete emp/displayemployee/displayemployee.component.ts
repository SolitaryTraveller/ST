import { Component, OnInit } from '@angular/core';
import { MyserviceService, Employee } from '../myservice.service';

@Component({
  selector: 'app-displayemployee',
  templateUrl: './displayemployee.component.html',
  styleUrls: ['./displayemployee.component.css']
})
export class DisplayemployeeComponent implements OnInit {

  service: MyserviceService;
  column: string = 'ecode';
  order: boolean = true;

  //emp:any[];

  constructor(service: MyserviceService) {
    this.service = service;
  }

  employees: Employee[] = []
  delete(deptId: number) {
    this.service.delete(deptId);
    this.employees = this.service.getEmployee();
  }



  //employees:Employee[]=[]
  // delete(ecode:number){
  //   this.service.delete
  // }



  //   this.emp=[
  //     {ecode:'emp101',ename:'Vaibhav',edesignation:"Trainer",eaddress:"Mumbai",edob:"11/11/2011",egender:'male',esal:'2000.00'},
  //     {ecode:'emp102',ename:'Kumar',edesignation:"Employee",eaddress:"Pune",edob:"12/12/2019",egender:'male',esal:'2400.00'},
  //     {ecode:'emp103',ename:'ComingSoon',edesignation:"Trainer2",eaddress:"Hydeerabdad",edob:"11/10/2017",egender:'Female',esal:'2900.00'},

  //   ]
  // }



  ngOnInit() {
    this.service.fetchEmployees();
    this.employees = this.service.getEmployee();
  }
  sort(column:string)
  {
    if(this.column == column)
    {
      this.order = ! this.order;
    }
    else
    {
      this.order = true;
      this.column = column;
    }
  }
}