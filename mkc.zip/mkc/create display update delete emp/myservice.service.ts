import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'; /// import
//import { Employees } from '@angular/core' // import

import { DeprecatedI18NPipesModule } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {

  http:HttpClient; //do
  employees:Employee[]=[]; //do 
  constructor(http:HttpClient) {  //do
    this.http=http; //do globally read data 
  }
  fetched:boolean=false;
  fetchEmployees() { //read data from employes.json and store in data
    this.http.get('./assets/Employees.json') //get files data read data
    
    .subscribe(
      data=>{
        if(!this.fetched){
          this.convert(data);
          this.fetched=true;
        }
      }
    );
    }
  
  getEmployee():Employee[]{ 
    return this.employees;
  }
  convert(data:any){
    for(let o of data){
      let e=new Employee(o.ecode,o.ename,o.edesignation,o.eaddress,o.edob,o.egender,o.esal);
      this.employees.push(e);
    }
  }

delete(ecode:number)
{
  let foundIndex:number=1;
  for(let i=0;i<this.employees.length;i++){
    let e=this.employees[i];
    if(ecode==e.ecode) {
      foundIndex=i;

      break;
    }
  }
  this.employees.splice(foundIndex,1);
}
add(e:Employee){
  this.employees.push(e);
  
}
update(e:Employee){
  for(let i=0;i<this.employees.length;i++){
  if(e.ecode==this.employees[i].ecode){
    this.employees[i].ename=e.ename;this.employees[i].edesignation=e.edesignation;this.employees[i].eaddress=e.eaddress;this.employees[i].edob=e.edob;this.employees[i].egender=e.egender;e.esal=e.esal;
    break;
  }
  
}
}}


export class Employee{
    ecode:number;
    ename:string;
    edesignation:string;
    eaddress:string;
    edob:string;
    egender:string;
    esal:string[];



    constructor(
      ecode:number,
      ename:string,
      edesignation:string,
      eaddress:string,
      edob:string,
      egender:string,
      esal:string[])
      {
        this.ecode=ecode;
        this.ename=ename;
        this.edesignation=edesignation;
        this.eaddress=eaddress;
        this.edob=edob;
        this.egender=egender;
        this.esal=esal;
      }

}