import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'orderby'
})
export class OrderbyPipe implements PipeTransform {

  transform(data: any[], column: string, order: boolean): any[] {
    if(order)
    {
      data.sort((a: any, b: any) => {
        if (a[column] > b[column]) {
          return 1;
        }
        else {
          return -1;
        }
      });
    }
    else
    {
      data.sort((a: any, b: any) => {
        if (a[column] < b[column]) {
          return 1;
        }
        else {
          return -1;
        }
      });
    }
    return data;
  }
}
