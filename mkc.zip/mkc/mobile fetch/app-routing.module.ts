import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MobileinfoComponent } from './mobileinfo/mobileinfo.component';


const routes: Routes = [

  // {
  //   path:'app-mobileinfo',
  //   component:MobileinfoComponent
  // },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
