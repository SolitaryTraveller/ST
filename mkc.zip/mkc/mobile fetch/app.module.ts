import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MobileinfoComponent } from './mobileinfo/mobileinfo.component';

import { HttpClientModule } from '@angular/common/http';
import { MyServiceService } from './my-service.service';
import { OrderbyPipe } from './orderby.pipe';

@NgModule({
  declarations: [
    AppComponent,
    MobileinfoComponent,
    OrderbyPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
    

  ],
  providers: [HttpClientModule,MyServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
