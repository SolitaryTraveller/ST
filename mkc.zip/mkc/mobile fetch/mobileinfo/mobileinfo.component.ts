import { Component, OnInit } from '@angular/core';
import { MyServiceService, Mobile } from '../my-service.service';

@Component({
  selector: 'app-mobileinfo',
  templateUrl: './mobileinfo.component.html',
  styleUrls: ['./mobileinfo.component.css']
})
export class MobileinfoComponent implements OnInit {

  service: MyServiceService;
  column: string = 'mobId';
  order: boolean = true;
  constructor( service:MyServiceService) {
    this.service=service;
   }

  mobiles: Mobile[] = []
  delete(mobId: number) {
    this.service.delete(mobId);
    this.mobiles = this.service.getMobile();
  }

  ngOnInit(){
    this.service.fetchMobile();
    this.mobiles = this.service.getMobile();
  }
  sort(column:string)
  {
    if(this.column == column)
    {
      this.order = ! this.order;
    }
    else
    {
      this.order = true;
      this.column = column;
    }
  }}
