import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
  http:HttpClient; 
  mobiles:Mobile[]=[];  
  constructor(http:HttpClient) {  
    this.http=http; 
    this.fetchMobile();
  }

  fetched:boolean=false;
  fetchMobile() { 
    this.http.get('./assets/mobile.json') 
    
    .subscribe(
      data=>{
        if(!this.fetched){
          this.convert(data);
          this.fetched=true;
        }
      }
    );
    }
  
  getMobile():Mobile[]{ 
    return this.mobiles;
  }
  convert(data:any){
    for(let g of data){
      let e=new Mobile(g.mobId,g.mobName,g.mobPrice);
      this.mobiles.push(e);
    }}
    delete(mobId:number)
{
  let foundIndex:number=1;
  for(let i=0;i<this.mobiles.length;i++){
    let e=this.mobiles[i];
    if(mobId==e.mobId) {
      foundIndex=i;

      break;
    }
  }
  this.mobiles.splice(foundIndex,1);
}

  
}
export class Mobile{
    mobId:number;
    mobName:string;
    mobPrice:string;
  

    constructor(
    mobId:number,
    mobName:string,
    mobprice:string)
      {
        this.mobId=mobId;
        this.mobName=mobName;
        this.mobPrice=mobprice;
        

}
  }

