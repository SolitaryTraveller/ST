import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'orderby'
})
export class OrderbyPipe implements PipeTransform {
  transform(data: any[], column: string, order: boolean){

    if(column==undefined){
      return data;
    }
    let sorted:any[];
    sorted=this.ascending(data,column);
    return sorted;
  }
  ascending(data:any[],column:string){
    data.sort((a: any, b: any) => {
      if (a[column] > b[column]) {
        return 1;
      }
      else {
        return -1;
      }
    });
  return data;

  }
     
}