import { Component, OnInit } from '@angular/core';
import { Product } from '../Product';
import { ProductServiceService } from '../product-service.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  products: Product[] = [];
  service: ProductServiceService;
  constructor(service: ProductServiceService) { this.service = service; }

  ngOnInit() {
    this.service.fetchProducts(); 
    this.products = this.service.getProducts();
  }
  delete(id: string) {
    this.service.delete(id);
    this.products = this.service.getProducts();
  }
}
