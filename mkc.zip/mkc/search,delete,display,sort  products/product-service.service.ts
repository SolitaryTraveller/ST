import { Injectable } from '@angular/core';
import { Product } from './Product';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductServiceService {
  products: Product[] = [];
  fetched: boolean = false;
  http: HttpClient;
  constructor(
    http: HttpClient) { this.http = http; }
  fetchProducts(): void {
    this.http.get('./assets/db.json').subscribe(data => {
      if (!this.fetched) {
        this.convert(data);
        this.fetched = true;
      }
    })
  }
  convert(data: any) {
    let product: Product;
    let prodData: any = data.products;
    for (var item of prodData) {
      product = new Product(item.id, item.name, item.price, item.category);
      this.products.push(product);
    }
  }
  getProducts(): Product[] {
    return this.products;
  }
  search(value: string): Product[] {
    let resultProducts: Product[] = [];
    for (var product of this.products) {
      if (product.name.toLowerCase() == value.toLocaleLowerCase() || product.category.toLocaleLowerCase() == value.toLocaleLowerCase()) {
        resultProducts.push(product);
      }
    }
    return resultProducts;
  }
  delete(id:string)
  {
    let foundIndex:number = -1;
    let len:number =  this.products.length;
    for(let i =0; i < len;i++)
    {
      let e = this.products[i];
      if(id == e.id)
      {
        foundIndex = i;
        break;
      }
    }
    this.products.splice(foundIndex,1);
  }
}
