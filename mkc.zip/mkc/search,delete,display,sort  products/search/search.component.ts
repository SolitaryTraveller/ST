import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Product } from '../Product';
import { ProductServiceService } from '../product-service.service';
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  searchForm: FormGroup;
  products: Product[] = [];
  service: ProductServiceService;
  constructor(service: ProductServiceService) {
  this.service = service;
  }

  ngOnInit() {
    this.searchForm = new FormGroup({
      searchValue: new FormControl()
    });
    this.service.fetchProducts();
  }
  search() {
    let searchValue: string = this.searchForm.controls.searchValue.value;
    // console.log(searchValue);
    this.products = this.service.search(searchValue);
    // console.log(this.products);
  }

}
